package com.digitaldetox.digital_detox

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
